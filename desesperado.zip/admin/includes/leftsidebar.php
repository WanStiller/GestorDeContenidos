<div class="left side-menu">
<div class="sidebar-inner slimscrollleft">
<!--- Lateral -->
<div id="sidebar-menu">
<ul>
<li class="menu-title">Administrador</li>
<li class="has_sub">
<a href="dashboard.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Principal </span> </a>
</li>
<li class="has_sub">
<a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Categor&iacute;as </span> <span class="menu-arrow"></span></a>
<ul class="list-unstyled">
<li><a href="add-category.php">Agregar Categor&iacute;as</a></li>
<li><a href="manage-categories.php">Administrar Categor&iacute;as</a></li>
</ul>
</li>
<li class="has_sub">
<a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span>Sub  Categor&iacute;as </span> <span class="menu-arrow"></span></a>
<ul class="list-unstyled">
<li><a href="add-subcategory.php">Agregar Sub Categor&iacute;as</a></li>
<li><a href="manage-subcategories.php">Administrar Sub Categor&iacute;as</a></li>
</ul>
</li>               
<li class="has_sub">
<a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Art&iacute;culos </span> <span class="menu-arrow"></span></a>
<ul class="list-unstyled">
<li><a href="add-post.php">Agregar Art&iacute;culos</a></li>
<li><a href="manage-posts.php">Administrar Art&iacute;culos</a></li>
<li><a href="trash-posts.php">Papelera</a></li>
</ul>
</li>  
<li class="has_sub">
<a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> P&aacute;ginas </span> <span class="menu-arrow"></span></a>
<ul class="list-unstyled">
<li><a href="hojadevida.php">Hoja de Vida</a></li>
<li><a href="portada.php">Portada</a></li>
</ul>
</li>
<li class="has_sub">
<a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Comentarios </span> <span class="menu-arrow"></span></a>
<ul class="list-unstyled">
<li><a href="unapprove-comment.php">Pendiente de Aprobaci&oacute;n </a></li>
<li><a href="manage-comments.php">Comentarios Aprobados</a></li>
</ul>
</li>
<li class="has_sub">
<a href="registered-users.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Registrados</span> </a>
</li>  
<li class="has_sub">
<a href="../index.php" class="waves-effect" target="_blank"><i class="mdi mdi-view-dashboard"></i> <span> Front</span> </a>
</li>   
</ul>
</div>
<!-- Sidebar -->
<div class="clearfix"></div>
<!--<div class="help-box">
<h5 class="text-muted m-t-0">Ayuda?</h5>
<p class=""><span class="text-custom">Correo:</span> <br/> joel@mail.com</p>
</div>-->
</div>
</div>
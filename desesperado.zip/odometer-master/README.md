Odometer
========

Odometer is a Javascript and CSS library for smoothly transitioning numbers.

### [Overview](http://github.hubspot.com/odometer/docs/welcome)
### [Docs and Demo](http://github.hubspot.com/odometer)

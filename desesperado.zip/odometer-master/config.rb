preferred_syntax = :sass
css_dir = './themes'
sass_dir = './sass'
output_style = :expanded
environment = :production
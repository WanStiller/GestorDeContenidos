<nav class="navbar navbar-expand-lg navbar-dark bg-dark"  style="margin-bottom: 1.5em;border-bottom: 5px solid #4f5b93;">
    <a class="navbar-brand" href="index.php"><img src="images/logo.png" style="width: 100%;max-width: 150px"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="login.php">Acceso</a>
            </li>

            <li class="nav-item active">
                <a class="nav-link" href="register.php">Registrarse</a>
            </li>
                           <li class="nav-item active">
                <a class="nav-link" href="hoja-de-vida.php"  style="color: yellow">MI <b>HOJA DE VIDA</b> <span class="icon icon-attachment"></span></a>
            </li>
        </ul>




      <form action="action/login.php" method="post" style="margin-bottom: 0px;">
      <div class="form-row">
      <input type="hidden" name="r" value="search/results">
<div class="container">
  <div class="row">
<div class="col-sm-3"><span style="color: white;font-size: 0.8em;">Tiene usted cuenta?<br><strong>INGRESAR:</strong></span></div>
<div class="col-sm-3">
        <input type="text"  name="email" class="form-control" placeholder="Email" required style="margin-top:5px;margin-bottom: 5px">
</div>
<div class="col-sm-3">
        <input type="password"  name="password" class="form-control" placeholder="Password" required style="margin-top:5px;margin-bottom: 5px">
</div>
<div class="col-sm-3"><button type="submit" class="btn btn-success" style="margin-top:5px;margin-bottom: 5px"><span class="icon icon-lock"></span> Acceder</button></div>
</div>
      </div>
    </form>


    </div>
</nav>


<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
/*var _smartsupp = _smartsupp || {};
_smartsupp.key = '3b967795bd44a5c351aeea54c5e67ea98579daef';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);*/
</script>
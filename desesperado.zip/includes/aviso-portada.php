<div class="alert alert-warning alert-dismissible fade show" role="alert" style="margin-bottom: 1.5em">
  Recomendamos activar una <b>cuenta</b> para acceder a todas las funcionalidades. Clic en este enlace para <a href="register.php">REGISTRARSE.</a> 
  Si usted ya tiene <b>cuenta</b>, <a href="login.php">INGRESA.</a>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
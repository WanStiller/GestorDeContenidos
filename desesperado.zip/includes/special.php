<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta content="Sitio Web de Entretenimiento" name="description">
<meta content="" name="author">
<title><?php echo $here; ?></title>
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.png">
<link rel="stylesheet" type="text/css" href="vendor/IcoMoon-Free-master/Font/demo-files/demo.css">
<link rel="stylesheet" type="text/css" href="odometer-master/themes/odometer-theme-minimal.css">
<meta property="og:image" content="images/preview.png">
</head>
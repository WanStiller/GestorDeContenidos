<div class="alert alert-success text-center" role="alert">
  Le informamos que usted tiene una sesi&oacute;n iniciada.
</div>